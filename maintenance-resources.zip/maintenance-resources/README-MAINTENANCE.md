# Fantasy Draft Labs Maintenance Resources

These files are not loaded by the live application. They are preserved for ranking imports, ADP updates, historical-data auditing, and future dataset rebuilding.

- `templates/ranking-import-template.csv`: optional complete ranking import schema.
- `templates/sleeper-adp-update-template.csv`: dated Sleeper ADP snapshot schema.
- `data-sources/bundled-sleeper-adp-baseline.csv`: bundled current baseline source.
- `data-sources/historical-adp-master.csv`: normalized 2018–2025 historical master.

The deployed browser dataset is `data/historical-adp-data.js` in the main project.
